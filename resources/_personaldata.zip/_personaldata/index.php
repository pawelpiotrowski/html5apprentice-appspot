<?php
	// wait 5 seconds
	// sleep(5);
	$url = urldecode('http://cdn.contentful.com/spaces/hbdg3afnrqv7/entries?content_type=204FqWl3MAcAosq0gMoKKm&access_token=2b9e567ba1502393bee07289559bdcb852a9349202178a3e6c0ba7a523067e62');
	$str = file_get_contents($url);
	echo($str);
?>