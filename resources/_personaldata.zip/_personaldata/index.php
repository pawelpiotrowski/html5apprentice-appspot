<?php
	// wait 5 seconds
	sleep(5);
	$str = file_get_contents('http://rumikom.com/datatest/content.json');
	echo($str);
?>